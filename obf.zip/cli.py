import sys
from engine import ObfuscatorEngine

if len(sys.argv) < 2:
    print("Usage: python cli.py <input.lua> [output.lua]")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2] if len(sys.argv) > 2 else "obfuscated.lua"

with open(input_file, "r", encoding="utf-8") as f:
    code = f.read()

obf = ObfuscatorEngine()
result = obf.obfuscate_b64(code)

with open(output_file, "w", encoding="utf-8") as f:
    f.write(result)

print(f"Saved to {output_file}")