import base64
import random
import string

class ObfuscatorEngine:
    def _random_name(self, length=3):
        return ''.join(random.choices(string.ascii_lowercase, k=length))
    
    def obfuscate_b64(self, code: str) -> str:
        code_bytes = code.encode("utf-8")
        b64_str = base64.b64encode(code_bytes).decode("utf-8")
        
        v1 = self._random_name(2)
        v2 = self._random_name(2)
        v3 = self._random_name(3)
        v4 = self._random_name(2)
        v5 = self._random_name(2)
        v6 = self._random_name(2)
        v7 = self._random_name(2)
        v8 = self._random_name(2)
        v9 = self._random_name(2)
        
        decoder_logic = f"""local {v1} = "...B64_PLACEHOLDER..."
local {v2} = nil

if type(crypt) == "table" and type(crypt.base64decode) == "function" then
    pcall(function() {v2} = crypt.base64decode({v1}) end)
elseif type(crypt) == "table" and type(crypt.base64) == "table" and type(crypt.base64.decode) == "function" then
    pcall(function() {v2} = crypt.base64.decode({v1}) end)
elseif type(base64_decode) == "function" then
    pcall(function() {v2} = base64_decode({v1}) end)
elseif type(base64) == "table" and type(base64.decode) == "function" then
    pcall(function() {v2} = base64.decode({v1}) end)
end

if not {v2} and game and game.HttpGet then
    pcall(function() {v2} = game:HttpGet("data:text/plain;base64," .. {v1}) end)
end

if not {v2} then
    local {v3} = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local {v4} = {{}}
    for i = 1, #{v3} do {v4}[{v3}:sub(i,i)] = i - 1 end
    local {v5} = {{}}
    local {v6}, {v7} = 0, 0
    for i = 1, #{v1} do
        local {v8} = {v1}:sub(i,i)
        if {v8} == "=" then break end
        if {v4}[{v8}] then
            {v6} = {v6} * 64 + {v4}[{v8}]
            {v7} = {v7} + 6
            if {v7} >= 8 then
                {v7} = {v7} - 8
                local {v9} = math.floor({v6} / (2 ^ {v7})) % 256
                table.insert({v5}, string.char({v9}))
                {v6} = {v6} % (2 ^ {v7})
            end
        end
        if i % 10000 == 0 then task.wait() end
    end
    {v2} = table.concat({v5})
end

local func, err = loadstring({v2})
if func then
    task.defer(func)
else
    warn("Obfuscation error: " .. tostring(err))
end"""
        
        decoder_logic = decoder_logic.replace("...B64_PLACEHOLDER...", b64_str)
        
        encoded = base64.b64encode(decoder_logic.encode("utf-8")).decode("utf-8")
        
        l1 = self._random_name(2)
        l2 = self._random_name(2)
        l3 = self._random_name(3)
        l4 = self._random_name(2)
        l5 = self._random_name(2)
        l6 = self._random_name(2)
        l7 = self._random_name(2)
        l8 = self._random_name(2)
        l9 = self._random_name(2)
        
        lua_template = f"""local {l1} = "{encoded}"

local function {l2}(s)
    local {l3} = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local {l4} = {{}}
    for i = 1, #{l3} do {l4}[{l3}:sub(i,i)] = i - 1 end
    local {l5} = {{}}
    local {l6}, {l7} = 0, 0
    for i = 1, #s do
        local {l8} = s:sub(i,i)
        if {l8} == "=" then break end
        if {l4}[{l8}] then
            {l6} = {l6} * 64 + {l4}[{l8}]
            {l7} = {l7} + 6
            if {l7} >= 8 then
                {l7} = {l7} - 8
                local {l9} = math.floor({l6} / (2 ^ {l7})) % 256
                table.insert({l5}, string.char({l9}))
                {l6} = {l6} % (2 ^ {l7})
            end
        end
    end
    return table.concat({l5})
end

local decoded = {l2}({l1})
loadstring(decoded)()"""
        
        return lua_template